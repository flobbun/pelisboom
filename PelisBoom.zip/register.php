<?php
include_once 'app/conection.inc.php';
include_once 'app/registerValidation.inc.php';


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>

  <!--CSS-->
  <link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
    integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

  <!--FONTS-->
  <link href="https://fonts.googleapis.com/css2?family=Inconsolata:wght@500&family=Lemonada:wght@500&display=swap" rel="stylesheet">
</head>

<body>
  <div class="container">
    <div class="login-div">
      <a href="index.php" id="gobackIcon">
        <svg width="2em" height="2em" viewBox="0 0 16 16" class="bi bi-box-arrow-left" fill="currentColor"xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd"d="M4.354 11.354a.5.5 0 0 0 0-.708L1.707 8l2.647-2.646a.5.5 0 1 0-.708-.708l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708 0z" /><path fill-rule="evenodd" d="M11.5 8a.5.5 0 0 0-.5-.5H2a.5.5 0 0 0 0 1h9a.5.5 0 0 0 .5-.5z" /><path fill-rule="evenodd"d="M14 13.5a1.5 1.5 0 0 0 1.5-1.5V4A1.5 1.5 0 0 0 14 2.5H7A1.5 1.5 0 0 0 5.5 4v1.5a.5.5 0 0 0 1 0V4a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-.5.5H7a.5.5 0 0 1-.5-.5v-1.5a.5.5 0 0 0-1 0V12A1.5 1.5 0 0 0 7 13.5h7z" /></svg>
      </a>
      <div class="logo">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRNrKXDgD3AD6Y3s1ffQgLL-AiAZOa1e8c7cQ&usqp=CAU"alt="">
      </div>
      <div class="title">Register</div>
      <div class="sub-title">PelisBoom 💥</div>

      <div class="fields">

        <div class="username"><svg fill="#999" viewBox="0 0 20 20"><path class="path1"d="M17.388,4.751H2.613c-0.213,0-0.389,0.175-0.389,0.389v9.72c0,0.216,0.175,0.389,0.389,0.389h14.775c0.214,0,0.389-0.173,0.389-0.389v-9.72C17.776,4.926,17.602,4.751,17.388,4.751 M16.448,5.53L10,11.984L3.552,5.53H16.448zM3.002,6.081l3.921,3.925l-3.921,3.925V6.081z M3.56,14.471l3.914-3.916l2.253,2.253c0.153,0.153,0.395,0.153,0.548,0l2.253-2.253l3.913,3.916H3.56z M16.999,13.931l-3.921-3.925l3.921-3.925V13.931z"></path></svg>

          <form method="post" action="">
            <!----USERNAME---->

            <input type="username" class="user-input" placeholder="username" required name="username" />

        </div>
        <?php 
              if(isset($_POST) && $warning_type_user != "")
              {
                echo $warning="<div class='alert'>$warning_type_user</div>";
              }
            ?>

        <!----EMAIL---->

        <div class="username"><svg fill="#999" viewBox="0 0 20 20"><path class="path1"d="M17.388,4.751H2.613c-0.213,0-0.389,0.175-0.389,0.389v9.72c0,0.216,0.175,0.389,0.389,0.389h14.775c0.214,0,0.389-0.173,0.389-0.389v-9.72C17.776,4.926,17.602,4.751,17.388,4.751 M16.448,5.53L10,11.984L3.552,5.53H16.448zM3.002,6.081l3.921,3.925l-3.921,3.925V6.081z M3.56,14.471l3.914-3.916l2.253,2.253c0.153,0.153,0.395,0.153,0.548,0l2.253-2.253l3.913,3.916H3.56z M16.999,13.931l-3.921-3.925l3.921-3.925V13.931z"></path></svg>

          <input type="email" required class="user-input" placeholder="email" name="email" />

        </div>
        <?php 
          if(isset($_POST) && $warning_type_email != "")
          {
            echo $warning="<br><div class='alert'>$warning_type_email</div>";
          }
          ?>
        <!----PASSWORD---->

        <div class="password"><svg fill="#999" viewBox="0 0 20 20"><pathd="M17.308,7.564h-1.993c0-2.929-2.385-5.314-5.314-5.314S4.686,4.635,4.686,7.564H2.693c-0.244,0-0.443,0.2-0.443,0.443v9.3c0,0.243,0.199,0.442,0.443,0.442h14.615c0.243,0,0.442-0.199,0.442-0.442v-9.3C17.75,7.764,17.551,7.564,17.308,7.564 M10,3.136c2.442,0,4.43,1.986,4.43,4.428H5.571C5.571,5.122,7.558,3.136,10,3.136 M16.865,16.864H3.136V8.45h13.729V16.864z M10,10.664c-0.854,0-1.55,0.696-1.55,1.551c0,0.699,0.467,1.292,1.107,1.485v0.95c0,0.243,0.2,0.442,0.443,0.442s0.443-0.199,0.443-0.442V13.7c0.64-0.193,1.106-0.786,1.106-1.485C11.55,11.36,10.854,10.664,10,10.664 M10,12.878c-0.366,0-0.664-0.298-0.664-0.663c0-0.366,0.298-0.665,0.664-0.665c0.365,0,0.664,0.299,0.664,0.665C10.664,12.58,10.365,12.878,10,12.878"></path></svg>

          <input type="password" required class="pass-input" placeholder="password" name="password" />

        </div>
        <?php 
          if(isset($_POST) && $warning_type_password != "")
          {
            echo $warning="<br><div class='alert'>$warning_type_password</div>";
          }
          ?>  
      </div>

      <button type="submit" name="send" class="register-button m-1">Register</button>

      <div class="link">
        <a class="m-2" href="login.php">Do you already have an account?</a>
        <a href="#">Forgot your password?</a>
        <br>
      </div>
      </form>

    </div>
  </div>
</body>

</html>
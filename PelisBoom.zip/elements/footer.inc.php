<div id="mainFooter" class="container-fluid text-center text-light">
    <footer>
        DevWeb → Jhon Aguiar
    </footer>
</div>


 <!------------------------>


    <!----Scripts--->
    <script src="js/main.js"></script>
</body>
<?php

//WEB ROOTS

define("SERVER","http://localhost/PelisBoom");
    define("REGISTER_ROOT",SERVER."/register.php");
    define("LOGIN_ROOT",SERVER."/login.php");
define("INDEXLOGIN_ROOT",SERVER."/indexLogIn.php");
define("SESIONCLOSED_ROOT",SERVER."/sesionclosed.php");
define("EMAILVERIFY_ROOT",SERVER."/emailverify.php");